import os
from cryptography.fernet import Fernet
from dotenv import load_dotenv, set_key
import requests

Global_Email = "yura2004@mail.ru"
friendemail = "Jarah@mail.ru"
# Загрузка переменных из .env
ENV_PATH = ".env"

# Генерация уникального ключа для сообщения
def generate_unique_key():
    return Fernet.generate_key().decode()

# Шифрование сообщения
def encrypt_message(message: str, key: str) -> str:
    cipher = Fernet(key.encode())
    return cipher.encrypt(message.encode()).decode()

# Расшифровка сообщения
def decrypt_message(encrypted_message: str, key: str) -> str:
    cipher = Fernet(key.encode())
    return cipher.decrypt(encrypted_message.encode()).decode()

# Основная логика
def process_message(message: str, user_id: int, friend_id: int):
    # Генерация уникального ключа для текущего сообщения
    unique_key = generate_unique_key()

    # Шифрование сообщения
    encrypted_message = encrypt_message(message, unique_key)

    # Отправка зашифрованного сообщения в базу данных
    response = requests.post(
        "http://localhost/process_message.php",
        data={"userId": user_id, "message": encrypted_message, "friendId": friend_id}
    )
    response_data = response.json()
    message_id = response_data["is_zayavki"]["messageId"]
    print(message_id)
    response2 = requests.post(
        "http://localhost/searchIdFromMesId.php",
        data={"userId": Global_ID, "friendId": Global_Friend_ID, "message_id": message_id}
    )
    json_response = response2.json()
    message_row_id = json_response.get("messageRowId")

    # Сохранение ID и ключа в .env
    set_key(".env", str(message_row_id), unique_key)

    print(f"Сообщение сохранено с ID {message_row_id} и уникальным ключом")
    load_dotenv(ENV_PATH, override=True)
    key = os.environ[str(message_row_id)]


    dec = decrypt_message(encrypted_message, key)
    print (dec)

# Пример вызова
if __name__ == "__main__":
    Global_ID = 1  # Пример ID пользователя
    Global_Friend_ID = 2  # Пример ID друга
    test_message = "Вот чёрт, опять!"

    process_message(test_message, Global_ID, Global_Friend_ID)
