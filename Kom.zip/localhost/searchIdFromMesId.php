<?php
// Подключение к базе данных
$servername = "127.0.0.1";
$username = "root"; // Ваше имя пользователя для подключения к базе данных
$password = ""; // Ваш пароль для подключения к базе данных
$dbname = "register"; // Имя вашей базы данных

// Создание соединения
$conn = new mysqli($servername, $username, $password, $dbname);

// Проверка соединения
if ($conn->connect_error) {
    die("Ошибка подключения к базе данных: " . $conn->connect_error);
}

// Получение данных из POST-запроса
$userId = isset($_POST['userId']) ? $_POST['userId'] : '';
$friendId = isset($_POST['friendId']) ? $_POST['friendId'] : '';
$messageId = isset($_POST['message_id']) ? $_POST['message_id'] : '';

// Определение chat_id (обеспечивает порядок ID)
$chat_id = ($userId < $friendId) ? "$userId, $friendId" : "$friendId, $userId";

// Поиск строки с message_id в таблице message
$stmt = $conn->prepare("SELECT id FROM message WHERE chat_id = ? AND message_id = ?");
$stmt->bind_param("si", $chat_id, $messageId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $messageRowId = $row['id'];

    // Формируем JSON-ответ
    $response = array(
        "success" => true,
        "messageRowId" => $messageRowId
    );
    header('Content-Type: application/json');
    echo json_encode($response);
} else {
    echo json_encode(array("success" => false, "error" => "Сообщение с таким message_id не найдено."));
}

// Закрытие соединения
$conn->close();
?>
