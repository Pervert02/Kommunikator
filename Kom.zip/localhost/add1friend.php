<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

// Подключение к базе данных
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "register";

// Создание соединения
$conn = new mysqli($servername, $username, $password, $dbname);

// Проверка соединения
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Получение данных от клиента
$main_user_id = $_POST['main_user_id']; // Email пользователя
$second_user_id = $_POST['s_user_id'];



function checkIfUserIsFriend($userId, $secondUserId, $conn) {
  // Выполняем SQL-запрос для получения строки с друзьями пользователя
  $sql = "SELECT friends FROM users WHERE id = $userId";
  $result = $conn->query($sql);

  // Предполагаем, что пользователь пока не является другом
  $userAlreadyFriends = false;

  // Проверяем, есть ли результат
  if ($result->num_rows > 0) {
      // Извлекаем данные из результата
      $row = $result->fetch_assoc();

      // Получаем значение friends из результата
      $friendsString = $row["friends"];

      // Разделяем строку на значения через запятую
      $friendsArray = explode(",", $friendsString);

      // Проверяем, содержит ли массив значение ID друга
      if (in_array($secondUserId, $friendsArray)) {
          // Если пользователь найден в списке друзей, устанавливаем флаг в true
          $userAlreadyFriends = true;
      }
  }

  // Возвращаем результат проверки
  return $userAlreadyFriends;
}

function checkIfUserIsZapros($userId, $secondUserId, $conn) {
  // Выполняем SQL-запрос для получения строки с друзьями пользователя
  $sql = "SELECT zapros FROM users WHERE id = $userId";
  $result = $conn->query($sql);

  // Предполагаем, что пользователь пока не является другом
  $userAlreadyFriends = false;

  // Проверяем, есть ли результат
  if ($result->num_rows > 0) {
      // Извлекаем данные из результата
      $row = $result->fetch_assoc();

      // Получаем значение friends из результата
      $friendsString = $row["zapros"];

      // Разделяем строку на значения через запятую
      $friendsArray = explode(",", $friendsString);

      // Проверяем, содержит ли массив значение ID друга
      if (in_array($secondUserId, $friendsArray)) {
          // Если пользователь найден в списке друзей, устанавливаем флаг в true
          $userAlreadyFriends = true;
      }
  }

  // Возвращаем результат проверки
  return $userAlreadyFriends;
}

function checkIfUserIsZayavki($userId, $secondUserId, $conn) {
  // Выполняем SQL-запрос для получения строки с друзьями пользователя
  $sql = "SELECT zayavki FROM users WHERE id = $userId";
  $result = $conn->query($sql);

  // Предполагаем, что пользователь пока не является другом
  $userAlreadyFriends = false;

  // Проверяем, есть ли результат
  if ($result->num_rows > 0) {
      // Извлекаем данные из результата
      $row = $result->fetch_assoc();

      // Получаем значение friends из результата
      $friendsString = $row["zayavki"];

      // Разделяем строку на значения через запятую
      $friendsArray = explode(",", $friendsString);

      // Проверяем, содержит ли массив значение ID друга
      if (in_array($secondUserId, $friendsArray)) {
          // Если пользователь найден в списке друзей, устанавливаем флаг в true
          $userAlreadyFriends = true;
      }
  }

  // Возвращаем результат проверки
  return $userAlreadyFriends;
}



// Проверка
//$sa=checkIfUserIsFriend($main_user_id,$second_user_id,$conn);
//echo json_encode(array("success" => false, "message" => "Пользователь 1 VQT $sa"));


if(checkIfUserIsFriend($main_user_id,$second_user_id,$conn) or checkIfUserIsZapros($main_user_id,$second_user_id,$conn) or checkIfUserIsZayavki($main_user_id,$second_user_id,$conn)){
  echo json_encode(array("success" => false, "message" => "Пользователь 1 уже есть в вашем списке друзей"));
  exit();
}
if(checkIfUserIsFriend($second_user_id,$main_user_id,$conn) or checkIfUserIsZapros($second_user_id,$main_user_id,$conn) or checkIfUserIsZayavki($second_user_id,$main_user_id,$conn)){
  echo json_encode(array("success" => false, "message" => "Пользователь 2 уже есть в вашем списке друзей"));
  exit();
}




// Обновление списка друзей для пользователя и его друга
$sqlUser = "UPDATE users SET zapros = CONCAT(zapros, ', $second_user_id') WHERE id = '$main_user_id'";
$sqlFriend = "UPDATE users SET zayavki = CONCAT(zayavki, ', $main_user_id') WHERE id = '$second_user_id'";

if ($conn->query($sqlUser) === TRUE && $conn->query($sqlFriend) === TRUE) {
  echo json_encode(array("success" => true, "message" => "Пользователи $main_user_id и $second_user_id успешно добавлены"));
} else {
  echo json_encode(array("success" => false, "message" => "Ошибка при добавлении пользователей в список друзей: " . $conn->error));
}

$conn->close();




?>
