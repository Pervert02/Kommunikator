<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

// Подключение к базе данных
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "register";

// Создание соединения
$conn = new mysqli($servername, $username, $password, $dbname);

// Проверка соединения
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Получение данных от клиента
$userid =  $_POST['userid']; // ID пользователя





// Получение списка друзей для пользователя с заданным userid
$userFriendsQuery = $conn->query("SELECT zayavki FROM users WHERE id = '$userid'");
if ($userFriendsQuery->num_rows > 0) {
  $userFriendsRow = $userFriendsQuery->fetch_assoc();
  $userFriends = explode(', ', $userFriendsRow['zayavki']);
  // Проверка наличия чисел в массиве
  $hasNumbers = false;
  foreach ($userFriends as $friend) {
      if (is_numeric($friend)) {
          $hasNumbers = true;
          break;
      }
  }

  // Если массив содержит хотя бы одно число, отправляем его
  if ($hasNumbers) {
      echo json_encode(array("success" => true, "is_zayavki" => $userFriends));
  } else {
      echo json_encode(array("success" => false, "message" => "В списке заявок нет чисел"));
  }
} else {
  echo json_encode(array("success" => false, "message" => "Пользователей не найдено"));
}

$conn->close();
?>
