<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

// Подключение к базе данных
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "register";

// Создание соединения
$conn = new mysqli($servername, $username, $password, $dbname);

// Проверка соединения
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Получение данных от клиента
$user_id = $_POST['userid']; // ID пользователя



$userDataQuery = $conn->query("SELECT name, email FROM users WHERE id = '$user_id'");
if ($userDataQuery->num_rows > 0) {
  $userData = $userDataQuery->fetch_assoc();
  echo json_encode(array("success" => true, "name" => $userData['name'], "email" => $userData['email']));
} else {
  echo json_encode(array("success" => false, "message" => "Пользователь с указанным ID не найден"));
}
$conn->close();
?>
