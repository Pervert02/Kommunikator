<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

// Подключение к базе данных
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "register";

// Создание соединения
$conn = new mysqli($servername, $username, $password, $dbname);

// Проверка соединения
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Получение данных от клиента
$userEmail = $_POST['user_email']; // Email пользователя
$userid = $_POST['userid']; // ID пользователя

// Проверка, что пользователь существует в базе данных
$userExistsQuery = $conn->query("SELECT * FROM users WHERE email = '$userEmail'");
if ($userExistsQuery->num_rows == 0) {
  echo json_encode(array("success" => false, "message" => "Пользователь с указанным email не найден"));
  exit();
}

// Получение id пользователя по его email
$userRow = $userExistsQuery->fetch_assoc();
$user_id = $userRow['id'];

// Получение списка друзей для пользователя с заданным userid
$userFriendsQuery = $conn->query("SELECT friends FROM users WHERE id = '$userid'");
if ($userFriendsQuery->num_rows > 0) {
  $userFriendsRow = $userFriendsQuery->fetch_assoc();
  $userFriends = explode(', ', $userFriendsRow['friends']);
  // Проверяем, является ли пользователь с user_id другом пользователя с указанным userid
  $isFriend = in_array($user_id, $userFriends);
  echo json_encode(array("success" => true, "is_friend" => $isFriend));
} else {
  echo json_encode(array("success" => false, "message" => "Пользователь с указанным userid не найден"));
}

$conn->close();
?>
