<?php
// Данные для подключения к базе данных
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "register";

// Получение данных из POST-запроса
$email = $_POST["email"];
$pass = $_POST["pass"];
$name = $_POST["name"];
$nothing = "";

if (empty($email) || empty($pass) || empty($name)) {
    echo "Ошибка: Необходимо заполнить все поля.";
} else {
    // Создание подключения
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Проверка соединения
    if ($conn->connect_error) {
        die("Ошибка подключения: " . $conn->connect_error);
    }
    // Проверка, существует ли пользователь с указанным email
    $check_sql = "SELECT * FROM users WHERE email = '$email'";
    $check_result = $conn->query($check_sql);

    if ($check_result->num_rows > 0) {
        echo "12293";
    }else{
        $sql = "INSERT INTO users (email, pass, name, friends, zapros, zayavki) VALUES ('$email', '$pass', '$name', '$nothing', '$nothing', '$nothing')";

        if ($conn->query($sql) === TRUE) {
            usleep(100000);
            // Теперь пытаемся выбрать добавленного пользователя
            $select_sql = "SELECT * FROM users WHERE email='$email'";
            $result = $conn->query($select_sql);
            if ($result->num_rows > 0) {
                // Пользователь найден
                $row = $result->fetch_assoc();
                echo "success".":". $row["id"].":".$row["name"];
            } else {
                // Пользователь не найден
                echo "Ошибка: Пользователь с email $email не найден.";
            }
        } else {
            echo "Ошибка: " . $conn->error;
        }
    }
    // Закрытие соединения
    $conn->close();
}

?>
