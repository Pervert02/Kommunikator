<?php
// Подключение к базе данных
$servername = "127.0.0.1";
$username = "root"; // Ваше имя пользователя для подключения к базе данных
$password = ""; // Ваш пароль для подключения к базе данных
$dbname = "register"; // Имя вашей базы данных

// Создание соединения
$conn = new mysqli($servername, $username, $password, $dbname);

// Проверка соединения
if ($conn->connect_error) {
    die("Ошибка подключения к базе данных: " . $conn->connect_error);
}

// Получение данных из POST-запроса
$userId = isset($_POST['userId']) ? $_POST['userId'] : '';
$message = isset($_POST['message']) ? $_POST['message'] : '';
$friendId = isset($_POST['friendId']) ? $_POST['friendId'] : '';

// Проверка, что данные не пустые
if (empty($userId) || empty($message) || empty($friendId)) {
    die("Ошибка: Одно или несколько обязательных полей пусты. userId: $userId, message: $message, friendId: $friendId");
}


// Получение максимального значения message_id для данной пары пользователей
$maxMessageIdQuery = "SELECT MAX(message_id) AS max_message_id FROM message WHERE chat_id = '$userId, $friendId' OR chat_id = '$friendId, $userId'";
$maxMessageIdResult = $conn->query($maxMessageIdQuery);
$maxMessageIdRow = $maxMessageIdResult->fetch_assoc();
$maxMessageId = $maxMessageIdRow['max_message_id'];
$newMessageId = $maxMessageId + 1;

// Записываем сообщение в таблицу message
$currentDateTime = date('Y-m-d H:i:s');
$chat_id = ($userId < $friendId) ? "$userId, $friendId" : "$friendId, $userId";
$sql = "INSERT INTO message (user_id, content, date_create, chat_id, message_id) VALUES ('$userId', '$message', '$currentDateTime', '$chat_id', '$newMessageId')";

if ($conn->query($sql) === TRUE) {
    // Формируем JSON для вывода всех столбцов для пользователей userId и friendId
    $response = array(
        "userId" => $userId,
        "messageId" => $newMessageId,
        "content" => $message,
        "dateCreated" => $currentDateTime
    );

    // Выводим JSON
    header('Content-Type: application/json');
    echo json_encode(array("success" => True, "is_zayavki" => $response));
} else {
    echo "Ошибка при отправке сообщения: " . $conn->error . "\nSQL: " . $sql;
}

// Закрытие соединения с базой данных
$conn->close();
?>
