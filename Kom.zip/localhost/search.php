<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

$name = $_POST['name'];

$mysql = new mysqli("127.0.0.1", "root", "", "register");

$result = $mysql->query("SELECT * FROM `users` WHERE `name` LIKE '%$name%'");

$users = array();
while ($row = $result->fetch_assoc()) {
    // Добавляем имя и почту пользователя в список
    $users[] = array('name' => $row['name'], 'email' => $row['email'], 'id' => $row['id'], 'friends' => $row['friends']);
}

if (!empty($users)) {
    echo json_encode(['status' => 'success', 'users' => $users]);
} else {
    echo json_encode(['status' => 'error', 'message' => 'No users found']);
}

$mysql->close();
?>
